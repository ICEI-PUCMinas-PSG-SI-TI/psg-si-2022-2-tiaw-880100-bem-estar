window.onload = () => {

    var dados = document.querySelectorAll(".dados");
    var pag_inicial = document.querySelectorAll(".pag_inicial");
    var ajuda = document.querySelectorAll(".ajuda");
    var sobre_nos =document.querySelectorAll(".sobre_nos");

    function scrollWinPagInicial() {
    window.scrollTo(0, 270);
  }


  function scrollWinDados() {
    window.scrollTo(0, 980);
  }


  function scrollWinSobre() {
    window.scrollTo(0, 1642);
  }


  function scrollWinAjuda() {
    window.scrollTo(0, 2100);
  }

}

